<?php require ('./inc/header.php'); 
echo "Image Gallery";
?>
