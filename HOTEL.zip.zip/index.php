<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Hotel Management System</title>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <style>
            #wrapper
            {
                width:50%;
                margin:auto;
            }
        </style>
    </head>
    <body>
        <div id="wrapper">

            <?php
                require_once 'header.php';
            ?>

            <h2>Welcome to Hotel Mariea</h2>

            <p> Welcome to Hotel Mariea, One of the Top three  Famous Hotels in the World. | The Staff Portal</p>

        </div>
        <?php
                require_once 'footer.php';
            ?>
    </body>
</html>
